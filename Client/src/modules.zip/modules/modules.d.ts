declare module '*.avif';
declare module '*.webp';
declare module '*.jpg';